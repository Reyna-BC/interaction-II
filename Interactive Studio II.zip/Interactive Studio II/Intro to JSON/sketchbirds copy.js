let data;

let birds;

function preload() {
 data = loadJSON("birds.json");
}

function setup() {
  createCanvas(800, 1000);
  birds = data.birds;
}


function draw() {
  background(0);

  for (let i = 0; i < birds.length; i++) {

  fill(255);
  textSize(34);
  
  text(birds[i].family, 15, 50 + i * 75);

  let members = birds[i].members;

  for (let j = 0; j < members.length; j++) {

    text(members[j], 15, 100 + j * 75 + i * 75);
  }
}
}