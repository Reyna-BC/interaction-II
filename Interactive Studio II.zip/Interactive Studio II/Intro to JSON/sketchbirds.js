let data;

function preload() {
 data = loadJSON("birds.json");
}

function setup() {
  createCanvas(400, 400);
}


function draw() {
  background(0);

  let bird = data.birds[6].members[7];

  fill(255);
  textSize(34);
  textAlign(CENTER);
  text(bird, width/2, height/2);
}
