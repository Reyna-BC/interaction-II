let flower;

function preload() {
  flower = loadJSON("flower.json");
}
function setup() {
  createCanvas(400, 400);
}


function draw() {
  background(0);

  fill(flower.r, flower.g, flower.b);
  textSize(34);
  text(flower.name, 150,200);
}
