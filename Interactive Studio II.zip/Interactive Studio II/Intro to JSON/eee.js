let data;
let birds;

function preload() {
  data = loadJSON("birds.json");
}

function setup() {
  createCanvas(800, 2500);
  birds = data.birds;
  textSize(24);
}

function draw() {
  background(0);
  fill(255);

  let y = 50;

  for (let i = 0; i < birds.length; i++) {
    // Display family name
    textSize(50);
    text(birds[i].family, 15, y);

    y += 40;

    // Display family members
    textSize(24);
    let members = birds[i].members;

    for (let j = 0; j < members.length; j++) {
      text(members[j], 35, y);
      y += 35;
    }

    // Space between families
    y += 25;
  }
}