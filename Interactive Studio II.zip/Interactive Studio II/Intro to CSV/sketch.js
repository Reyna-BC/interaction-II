let data;

let url = "https://docs.google.com/spreadsheets/d/e/2PACX-1vQ0uuGtjdugicOdehzDRB_TvUMi84gh5woQCwo0mGrPHNkp5VjApM3nsr8f4Jz2pE4cLtBMunDQyYrs/pub?gid=0&single=true&output=csv";

function setup() {
  createCanvas(800, 500);
}

function preload() {
  data = loadTable(url, "csv", "header");
  console.log(data);
}

function draw() {
  background(220);

  if (data) {
    let numRows = data.getRowCount();
      let carbs = data.getColumn("Win Rate");
      let names = data.getColumn("Heros");

    for (let i = 0; i < numRows; i++) {
      let x = 50;
      let y = 100 + i * 50;
      let w = carbs[i];
      let h = 10;

      rect(x, y, w, h);

      textAlign(LEFT);
      fill(0);
      text(names[i], x, y - 5);

      textAlign(CENTER);
      text("Win Rate", width / 2, 50);
    }
  }
}
