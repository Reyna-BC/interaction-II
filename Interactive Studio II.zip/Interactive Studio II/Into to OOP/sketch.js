let car1 = {
  x: 50,
  y: 75,
};

let cars = [];


function setup() {
  createCanvas(1000, 900);
  // make a new car
  //cars[0] = new Car(color(255, 0, 0), 50, 75, 1);
  //cars[1] = new Car(color(0, 291, 35), 50, 125, 3);

  for (let i = 0; i < 100; i++) {

    // let y = 10 + 50 * i;
    let y = random(10, height - 10);
    cars[i] = new Car(color(random(255), random(255), random(255)), 50, y, random(5));
  }
}

function draw() {
  background(220);
  // cars[0].display();
  // cars[0].drive();

  // cars[1].display();
  // cars[1].drive();

  for (let i = 0; i < cars.length; i++) {
    cars[i].display();
    cars[i].drive();
  }
  }

class Car {
  constructor(c, xpos, ypos, xspeed) {
    this.c = c;
    this.xpos = xpos;
    this.ypos = ypos;
    this.xspeed = xspeed;
  }

  display() {
    stroke(0);
    rectMode(CENTER);
    fill(this.c);
    rect(this.xpos, this.ypos, 30, 10);
  }

  drive() {
    this.xpos = this.xpos + this.xspeed;

    if (this.xpos > width) {
      this.xpos = 0;
    }
  }
}